from django.apps import AppConfig


class BankingAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'banking_app'
